// fetch('https://jsonplaceholder.typicode.com/users')
//       .then(response => response.json())
//       .then(Students => {
//           for (let i = 0; i < Students.length; i++) {    
//             var option = document.createElement('option')
//             option.innerHTML = Students[i].name;
//             document.getElementById('AZ').appendChild(option);}
//       })

fetch('https://restcountries.com/v3.1/all')
      .then(response => response.json())
      .then(Countries => {
          for (let i = 0; i < Countries.length; i++) {    
            var option = document.createElement('option')
            option.innerHTML = Countries[i].name.common;
            document.getElementById('AZ').appendChild(option);

            var img = document.createElement('img');
            img.src = Countries[i].flags.png;
            document.getElementById('MB').appendChild(img);
          }
      })