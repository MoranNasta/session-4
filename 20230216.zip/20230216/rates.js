var currencies = ['EUR','LBP','SAR','JOD']
for (let i = 0; i < currencies.length; i++) {
        var option = document.createElement('option')
        option.innerHTML = currencies[i];
        document.getElementById('Currencies').appendChild(option);
}

function ExchangeRate(){
   var selectedCurrency = document.getElementById('Currencies').value;
   var URL = 'https://api.fastforex.io/fetch-multi?from=' + selectedCurrency + '&to=USD&api_key=44f6199b5e-09d8d7c00a-rq6qpw'
   fetch(URL)
      .then(response => response.json())
      .then(response => {
        _exchangRate = response.results.USD;
        _amount = document.getElementById('Amount').value;
        //console.log(_exchangRate);
        //console.log(_amount);
        _ExchangedAmount = _amount * _exchangRate;
        //console.log(_ExchangedAmount)
        document.getElementById('ExchangeAmount').innerHTML = _ExchangedAmount.toFixed(2);
      });
}